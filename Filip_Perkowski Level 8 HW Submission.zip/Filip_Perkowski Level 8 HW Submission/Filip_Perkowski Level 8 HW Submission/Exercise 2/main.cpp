//With boost tuples, we can store elements of different data types in one container
//This is similar to tuples in Python

//Objective -> In this file, we create a typedef alias for a specific tuple configuration. And manipulate it/extract elements from it

#include "boost/tuple/tuple.hpp"
#include "boost/tuple/tuple_io.hpp"

#include <iostream>
#include <sstream>
#include <string>

using boost::tuple;

typedef tuple<std::string, int, double> Person;

//Function which will print out the Person tuple
void ptuple(Person c) {
	
	//get<>() to retrieve elements from a tuple
	std::string one = c.get<0>();
	int two = c.get<1>();
	double three = c.get<2>();

	std::cout << "Hi I am " << one << " I am " << two << " years old" << " and " << three << " feet tall" << std::endl;


}



int main() {
	
//Now let's make some tuples:
	Person p1 = boost::make_tuple("Maggy", 19, 3.2);
	Person p2 = boost::make_tuple("Greg", 43, 4.6);
	Person p3 = boost::make_tuple("Marge", 7, 8.2);

	//Printing the tuples out
	ptuple(p1);
	ptuple(p2);
	ptuple(p3);


	//Add 1 to the age of Maggy; We can use get<>() to do this
	p1.get<1>() = p1.get<1>() + 1; //Now Maggy is 20

	//Checking to see if Maggy's age got incremented by 1
	std::cout << "---" << '\n';
	std::cout << "It's Maggy's birthday today" << std::endl;
	ptuple(p1);




}
