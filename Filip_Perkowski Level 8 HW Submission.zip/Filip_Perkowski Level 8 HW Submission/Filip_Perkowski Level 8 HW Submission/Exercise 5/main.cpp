//Objective -> Here we want to change the code so that we are dealing with -> the exponential distribution instead of the normal distribution
//Working with the Poisson distribution -> instead of the Gamma distribution

#include "boost/math/distributions/exponential.hpp"
#include "boost/math/distributions/poisson.hpp"
//#include "boost/math/distributions.hpp" //Alternaitvely we can just include the header file which includes all the math distributions

#include <vector>
#include <iostream>

using namespace std;
using namespace boost::math;


int main()
{

	double myparam = .5;
	cout.precision(4); //4 decimal places after the period(.)

	//Our Exponential Distribution
	exponential_distribution<> myExp1(myparam); // Default type is 'double' //myExp is a exponential_distribution object; We see that that these distributions are defined by the fact that <> notation is present in when decleraring the object
	
	
	//Properties of the Exponential Distribution
	cout << "Exponential Distribution: \n";
	cout << "Mean: " << mean(myExp1) << std::endl;
	cout << "STDEV: " << standard_deviation(myExp1) << std::endl;

	double x = 10.25;
	
	cout << "pdf: " << pdf(myExp1, x) << endl;
	cout << "cdf: " << cdf(myExp1, x) << endl;

	cout << "variance: " << variance(myExp1) << endl; 
	cout << "median: " << median(myExp1) << endl; 
	cout << "mode: " << mode(myExp1) << endl;
	cout << "kurtosis excess: " << kurtosis_excess(myExp1) << endl;
	cout << "kurtosis: " << kurtosis(myExp1) << endl;
	cout << "characteristic function: " << chf(myExp1, x) << endl; 
	cout << "hazard: " << hazard(myExp1, x) << endl; 


	// Poisson distribution
	double p1 = 3.0;

	poisson_distribution<double> myPoisson(p1); //myPoisson is our poisson_distribution object

	cout << "--------" << std::endl;

	//Properties of the Poission Distribution
	cout << "Poisson Distribution: \n";
	cout << endl << "pdf: " << pdf(myPoisson, x) << endl;
	cout << "cdf: " << cdf(myPoisson, x) << endl;

	cout << "Variance: " << variance(myPoisson);
	cout << "Mode: " << mode(myPoisson);
	cout << "STDEV: " << standard_deviation(myPoisson);
	cout << "Mean: " << mean(myPoisson) << std::endl;
	cout << "Kurtosis: " << kurtosis(myPoisson) << std::endl;
	cout << "Kurtosis Excess: " << kurtosis_excess(myPoisson) << std::endl;
	cout << "Characteristic function: " << chf(myPoisson, x) << endl; 
	cout << "Hazard: " << hazard(myPoisson, x) << endl; 

	cout << "--------" << std::endl;

	vector<double> pdfList;
	vector<double> cdfList;

	double start = 0.0;
	double end = 10.0;
	long N = 30;		// Number of subdivisions

	double val = 0.0;
	double h = (end - start) / double(N);

	for (long j = 1; j <= N; ++j)
	{
		pdfList.push_back(pdf(myPoisson, val));
		cdfList.push_back(cdf(myPoisson, val));

		val += h;
	}

	//Vector PDFList printed out element by element
	for (long j = 0; j < pdfList.size(); ++j)
	{
		cout << pdfList[j] << ", ";

	}

	cout << "***" << endl;


	//Vector CDFList printed out element by element
	for (long j = 0; j < cdfList.size(); ++j)
	{
		cout << cdfList[j] << ", ";

	}

}

