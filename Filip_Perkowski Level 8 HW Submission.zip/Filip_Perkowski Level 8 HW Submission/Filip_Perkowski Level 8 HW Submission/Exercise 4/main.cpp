#include "boost/random.hpp"
#include "boost/math/distributions.hpp" //By writing this we are including all the distributions at once
#include <ctime>
#include <map>
#include <iostream>
#include <sstream>

//Objective -> In this file, we imlpement probabilities(of rolling a dice 1-6) into a map over the course of N trials

int main() {

	boost::random::mt19937 Rng1; //Our Random Number generator object

	Rng1.seed(static_cast<boost::uint32_t>(std::time(0)));

	boost::random::uniform_int_distribution<int> resi(1, 6);

	std::map<int, long> statistics; //Our map object

	int outcome;
	long int n_trials; //Variable to hold the number of trials

	std::cout << "Number of trails? ";
	std::cin >> n_trials;

	long count_1 = 0, count_2 = 0, count_3 = 0, count_4 = 0, count_5 = 0, count_6 = 0;

	for (int i = 0; i <= n_trials; i++) {
		outcome = resi(Rng1);
		//if statement branch
		if (outcome == 1) {
			count_1 += 1;
		}

		if (outcome == 2) {
			count_2 += 2;
		}

		if (outcome == 3) {
			count_3 += 3;
		}

		if (outcome == 4) {
			count_4 += 4;
		}

		if (outcome == 5) {
			count_5 += 5;
		}

		if (outcome == 6) {
			count_6 += 6;
		}

	}

		//Implementing these long values as elements in our map; Key is the outcome(number rolled via dice); Value is the number of times each number was rolled
		statistics[1] = count_1;
		statistics[2] = count_2;
		statistics[3] = count_3;
		statistics[4] = count_4;
		statistics[5] = count_5;
		statistics[6] = count_6;


		for (std::map<int, long>::const_iterator itr = statistics.begin(); itr != statistics.end(); itr++) {
			std::cout << "Trial " << itr->first << " has " << double(itr->second) / double(n_trials) * 100 << " % outcomes " << std::endl;
		}



	}
