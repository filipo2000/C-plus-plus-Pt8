#pragma once

#ifndef Circle_h
#define Circle_h

#include <iostream>
#include <sstream>
#include <string>
#include "Line.h" //By including the Line header file we are indirectly also including the Point header file. This is because the Line header file itself include the Point class header file
#include "Shape.h"

//Objective -> In this file we declare all the components within the Circle class

namespace Filip {
	namespace CAD {
		class Circle : public Shape { //Now the Circle Class inherits from the Shape class. We can use a object of type class circle and use it to acess members in the Shape class
		private:
			Point m_point;
			double m_radius;
		public:
			//Our constructors and deconstructor
			Circle();
			Circle(Point a, double b);
			Circle(const Circle& c);
			~Circle();

			//Our Set() Functions
			Point CentrePoint() const;
			double Radius() const;

			//Our Get() Functions
			void CentrePoint(const Point& a);
			void Radius(const double& b);

			//= Operator Function
			Circle& operator=(const Circle& c);

			//ToString() Function
			std::string ToString() const;

			//Measurement Functions
			double Area() const;
			double Circumfrence() const;
			double Diameter() const;

		};

	}
}


//Operator<< Function is outside our Circle class
std::ostream& operator<<(std::ostream& o, const Filip::CAD::Circle& c);

#endif