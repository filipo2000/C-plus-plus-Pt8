#pragma once

#ifndef Array_h
#define Array_h

#include "OutOfBoundsException.h"

//Objective -> In this file, we declare all the components within the Array class

namespace Filip {
	namespace Containers {
		template <typename T>
		class Array {
		private:
			T* m_data; //Since Point is wihtin the CAD namespace we need to do CAD:: individuall or using Filip::CAD::Point or using namespace Filip::CAD
			int m_size;
			static int default_size; //Making this variable a static variable
		public:
			Array();
			Array(int sz);
			Array(const Array<T>& c);
			~Array();

			int Size() const;

			//Functions() which will work on the underlying Array class object
			static int DefaultSize(); //This function will return the static variable deafult_size -> Get() Function
			static void DefaultSize(int a); //This function will set the static variable default_size -> Set() Function

			void SetElement(T* p, int index);
			T& GetElement(int index) const;

			Array<T>& operator=(const Array<T>& source);

			T& operator[](int index);
			const T& operator[](int index) const;
		};
	}
}

//When dealing with template classes these preprocessor directives are necessary
#ifndef Array_cpp //This prohibits multiple inclusion of our Array.cpp source file; Makes sure that the Array.cpp source file is included only once -> pairs it up only once with our Array.h file
#include "Array.cpp" 
#endif

#endif
