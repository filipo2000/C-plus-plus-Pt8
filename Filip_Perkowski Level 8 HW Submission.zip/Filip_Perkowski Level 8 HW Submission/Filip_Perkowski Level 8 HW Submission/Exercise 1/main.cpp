
//When you create an object of class type and alongside it you put () -> this makes it so that we initiate the constructor from the class
//When we create a object of class type we don't need to apply the ()


//boost::shared pointer -> this is a pointer type from the boost library. With boost::shared pointer the object which the shared pointer points to automatically gets deleted once no shared pointer points to it anymore

//A shared pointer is a type of smart pointer

//shared_ptr in define as a template; We use the typedef key word for a typename alias

//Objective -> Here we create an Array of ShapePtr's and test the attributes of shared pointers -> more specifically of our ShapePtr elements

//Inclding our boost pointer header file
#include "boost/shared_ptr.hpp"
#include <iostream>
#include <sstream>

#include "Shape.h"
#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Array.h"

//Including the appropriate namespaces
using namespace Filip::Containers;
using namespace Filip::CAD;

typedef boost::shared_ptr<Shape> ShapePtr; //So here Shapeptr is another name for a shared pointer that point to an object of class type Shape
typedef Array<ShapePtr> ShapeArray; //ShapeArray is another name for our Array or shared pointers. Aka Array class type object that contains ShapePtr as it's elements/components

int main() {

	ShapeArray arr1(4); //Our object

	//Inputting elements of arr1 -> pointers which points to shapes 
	arr1[0] = ShapePtr(new Point(8, 12)); //So the first element in arr1 is a shared_ptr pointer that points to Point(8,12)
	arr1[1] = ShapePtr(new Point(7, 1));
	arr1[2] = ShapePtr(new Line(Point(30, 18), Point(12, 3)));
	arr1[3] = ShapePtr(new Circle(Point(3, 4), 10));


	for (int i = 0; i < 4; i++) {
		std::cout << arr1.GetElement(i)->ToString() << std::endl; 
	}

	std::cout << '\n';

	//Here the counts are 1; 1 pointer is pointing to Point(8,12) etc. 
	std::cout << arr1[0].use_count() << std::endl;
	std::cout << arr1[0].use_count() << std::endl;
	std::cout << arr1[0].use_count() << std::endl;

	std::cout << '\n';

	//By making our shared pointers NULL, there are no more pointers pointing to Shapes: Point(8,12) etc. hence all of these shapes will get deleted  
	arr1[0] = NULL;
	arr1[1] = NULL;
	arr1[2] = NULL;
	arr1[3] = NULL;

	//We can confirm the above by showing that the counts are 0
	std::cout << arr1[0].use_count() << std::endl;
	std::cout << arr1[0].use_count() << std::endl;
	std::cout << arr1[0].use_count() << std::endl;


	
}





