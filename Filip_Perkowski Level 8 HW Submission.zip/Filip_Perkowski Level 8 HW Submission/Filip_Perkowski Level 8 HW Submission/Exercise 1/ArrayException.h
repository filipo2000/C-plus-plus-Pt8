#pragma once

#ifndef ArrayException_h
#define ArrayException_h

#include <string>

//Objective -> This is the header file for our Array Exception Class -> Here we declare and define the components of the Array Exception class
//Size() function reffers to the Size() function in the Array class

class ArrayException {
private:

public:
	//Constructor and Deconstructor
	ArrayException() {}
	virtual ~ArrayException() {}

	//GetMessage() Function
	virtual std::string GetMessage() const = 0;


};



#endif