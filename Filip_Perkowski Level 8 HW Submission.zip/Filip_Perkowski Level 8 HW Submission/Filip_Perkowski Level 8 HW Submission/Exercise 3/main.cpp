//A tuple container from the boost library can hold different types of elements
//This is not the case with variants where all the elements have to be of the same type

//Pass By Value -> Here a copy is made so the argument passed into the function isin't changed
//Pass by reference -> Here since parameter is a reference to the parameter changing the parameter in the function body we are also simultaneously changing the value of the argument as well; Since the parameter would be simply a refrence/alias for the argument passed to the function which we would like to call

//With regular pointers whenever, a pointer is out of scope it is terminated however, the object that the pointer points to is still active in memory. This is the main source of memory leaks. To prohibit this from occuring we have smart pointers
//When ever we use regular pointers and the new keyword we need to use the delete keyword to free up the memory that the object that the pointer pointed to took up
//Smart pointers are a special subset of pointers that make sure that the object that they point to gets deleted; The pointer does this on it's own whenever the pointer itself is out of scope. So that there's no unecessary memory allocation which could lead to a memory leak
//We have different types of Smart Pointers -> Unique Pointer, Shared Pointer etc. When we create any of these pointer types it must be done in template notation since they're defined as a template class in the C++ standard library

//malloc -> Reffers to memroy allocation

//Objective -> In this file we crete a variant combination + test it by applying visitors/respective functions to it

#include "boost/variant.hpp"
using boost::variant;

#include <iostream>
#include <sstream>

#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Shape.h"
#include "visitor.h"

//Don't forget about this otheriwise the header file inclusion here is worthless since we coldn't be able to use what's in the scope of the Filip and CAD namespaces in the respective header files
using namespace Filip::CAD;

typedef variant<Point, Line, Circle> Shapetype; //Variant just like all the other containers in the boost library are defined by a template class hence the <> notation


//Our Function which returns a shape as requested by the user
Shapetype ShapeV(){ //Our function called Shape
	Shapetype vars;
	int pick;
	std::cout << "What shape would you like to create: 1 for Point, 2 for Line and 3 for Circle: "; //Input will be either Point, Line or Circle
	std::cin >> pick;

	//if branch statement 
	if(pick == 1) {
		return Point(5, 5);
	}
	else if(pick == 2) {
		return Line(Point(5,5), Point(5,5));
	}

	else if(pick == 3) {
		return Circle(Point(5,5), 5);
	}

	else {
		std::cout << "Input is invalid";
	}
}



int main() {

	//Printing out ShapeV()
	std::cout << ShapeV() << std::endl;
	std::cout << '\n';
	
	//For this try catch we will get an error because we didn't use Line() alongside <Line>  in get<>()
	Line l1; //Line variable
	Shapetype point_v = Point(); //So our variant configuration point_v only has a Point Shape type as an element

	try {
		l1 = boost::get<Line>(point_v); //Our variant doesn't contain a Line element hence an error will be thrown
		std::cout << l1.ToString() << std::endl;
	}

	catch (boost::bad_get& err) {
		std::cout << err.what() << std::endl;

	}


	//Testing the apply_visitor global function to see if each shape's coordinates moved
	std::cout << "------" << std::endl;
	
	Visitor p_visitor (2, 2); //This is how much Point(5,5) will be moved by
	Shapetype p_variant = Point(5,5);
	std::cout << "Pre moving: " << p_variant << std::endl;

	boost::apply_visitor(p_visitor, p_variant);
	std::cout << "Post moving: " << p_variant << std::endl; //Point(7,7)

	std::cout << "------" << std::endl;

	Visitor l_visitor(5, 5);
	Shapetype l_variant = Line(Point(10,20), Point(3,6));
	std::cout << "Pre moving: " << l_variant << std::endl;

	boost::apply_visitor(l_visitor, l_variant);
	std::cout << "Post moving: " << l_variant << std::endl; //Line with points: Point(15,25) , Point(8,11)

	std::cout << "------" << std::endl;

	Visitor c_visitor(5, 5); //Calling the (double, double) constructor from the Visitor class
	Shapetype c_variant = Circle(Point(5,5), 6);
	std::cout << "Pre moving: " << c_variant << std::endl;

	boost::apply_visitor(c_visitor, c_variant);
	std::cout << "Post moving: " << c_variant << std::endl; //Circle with centre point Point(10,10)



}