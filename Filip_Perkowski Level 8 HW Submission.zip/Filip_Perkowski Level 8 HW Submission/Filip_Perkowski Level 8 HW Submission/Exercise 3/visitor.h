#pragma once

#ifndef Visitor_h
#define Visitor_h

#include "boost/variant.hpp"

#include "Point.h"
#include "Line.h"
#include "Circle.h"
#include "Shape.h"

//Objective -> In this file we declare and define all the components in the visitor header file

using namespace Filip::CAD;

class Visitor : public boost::static_visitor<>
{
	private:
		double m_x;
		double m_y;


public:
		//Defining our constructors in the header file
		Visitor() :m_x(0), m_y(0) {}
		Visitor(double a, double b): m_x(a), m_y(b) {}
		Visitor(const Visitor& source): m_x(source.m_x), m_y(source.m_y) {}
		~Visitor() {}

		void operator()(Point& p) { //Moving the Point shape
			p.X(p.X() + m_x);
			p.Y(p.Y() + m_y);
		}
		 
		void operator()(Line& l) { //Moving the Line shape
			
			//First point of line
			Point p_1 = l.P1();
			p_1.X(p_1.X() + m_x); //Adjusting the x and y coordinates of our Line object l which is a refrence an alias for the argument passed whenver we call this function
			p_1.Y(p_1.Y() + m_y);
			l.P1(p_1);

			//Second point of line
			Point p_2 = l.P2();
			p_2.X(p_2.X() + m_x); //Adjusting the x and y coordinates of our Line object l which is a refrence an alias for the argument passed whenver we call this function
			p_2.Y(p_2.Y() + m_y);
			l.P2(p_2);

		}

		void operator()(Circle& c) { //Moving the Circle shape
			Point p_1 = c.CentrePoint();
			p_1.X(p_1.X() + m_x); 
			p_1.Y(p_1.Y() + m_y);
			c.CentrePoint(p_1); //Now c's centre point are of coordinates designated by Point p_1
		}


};
















#endif